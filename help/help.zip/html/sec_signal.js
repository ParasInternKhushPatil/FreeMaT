var sec_signal =
[
    [ "CONV Convolution Function", "signal_conv.html", [
      [ "", "signal_conv.html#Usage", null ]
    ] ],
    [ "CONV2 Matrix Convolution", "signal_conv2.html", [
      [ "", "signal_conv2.html#Usage", null ],
      [ "Internals", "signal_conv2.html#Function", null ]
    ] ]
];